#ifndef FILELOCATIONS_H
#define FILELOCATIONS_H
#include <QString>

const static QString c_CustomGatesLocation = "CustomGates/";
const static QString c_tasksLocation = "Tasks/";

#endif // FILELOCATIONS_H

#ifndef ENUMS_H
#define ENUMS_H

#endif // ENUMS_H

enum ClickMode
{
    CLICK_DRAG,
    CLICK_DELETE_GATE,
    CLICK_LINK_NODES,
    CLICK_DELETE_LINK_NODES,
    CLICK_SELECTION,
    CLICK_PAN,
    CLICK_DEFAULT
};

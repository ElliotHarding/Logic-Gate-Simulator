#include "truthtables.h"



#ifndef TRUTHTABLES_H
#define TRUTHTABLES_H

#include "vector"


#endif // TRUTHTABLES_H
